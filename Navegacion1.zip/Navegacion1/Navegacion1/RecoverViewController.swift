//
//  RecoverViewController.swift
//  Navegacion1
//
//  Created by David Yanac on 19/05/22.
//

import UIKit

class RecoverViewController: UIViewController {
    
}


//
//  DetailViewController.swift
//  Navegacion1
//
//  Created by David Yanac on 16/05/22.
//

import UIKit

class RegisterViewController: UIViewController {
    
}
